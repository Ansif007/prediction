import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Prediction App",
  description: "Predict match results",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}